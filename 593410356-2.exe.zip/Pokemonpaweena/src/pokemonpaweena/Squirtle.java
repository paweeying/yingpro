/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokemonpaweena;

/**
 *
 * @author ACER
 */
public class Squirtle extends POKEMON{
    public   String[] skillname = {"Tackle","Aqua Jet","Aqua Tail","Water Pulse"};
    public Squirtle(){
        
        this.name = "Sqirtle";
        this.hp = 1000;
        this.attack = 400;
        this.defense = 200;
    }
    
}
