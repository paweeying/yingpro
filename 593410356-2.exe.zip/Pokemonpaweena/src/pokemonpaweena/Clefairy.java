/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokemonpaweena;

/**
 *
 * @author ACER
 */
public class Clefairy extends POKEMON {
    public   String[] skillname = {"Zen Headbutt","Body Slam"," Disarming Voice","Moonblast"};
    public  Clefairy(){
       
        this.name = " Clefairy";
        this.hp = 600;
        this.attack = 300;
        this.defense = 100;
}
}