/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokemonpaweena;

/**
 *
 * @author ACER
 */
public class Charmander extends POKEMON {
    public   String[] skillname = {"Ember","Flame Burst","Flamethrower","Flame Charge"};
    public  Charmander(){
       
        this.name = " Charmander";
        this.hp = 800;
        this.attack = 400;
        this.defense = 200;
}
}