/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokemonpaweena;

/**
 *
 * @author ACER
 */
public class Bulpix extends POKEMON {
    public   String[] skillname = {"Ember","Flamethrower","Body Slam"," Flame Charge"};
    public  Bulpix(){
       
        this.name = " Bulpix";
        this.hp = 300;
        this.attack = 200;
        this.defense = 400;
}
}