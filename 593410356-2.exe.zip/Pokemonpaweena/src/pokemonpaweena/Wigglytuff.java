/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokemonpaweena;

/**
 *
 * @author ACER
 */
public class Wigglytuff extends POKEMON {
    public   String[] skillname = {"Feint Attack","Dazzling Gleam","Hyper Beam"," Play Rough("};
    public  Wigglytuff(){
       
        this.name = " Wigglytuff";
        this.hp = 700;
        this.attack = 100;
        this.defense = 200;
}
}